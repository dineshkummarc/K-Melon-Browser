//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by sessions.rc
//
#define IDD_PROMPT                      101
#define IDD_CONFIG                      102
#define IDS_SESSION_RECOVERY_MSG        104
#define IDS_SESSION_RECOVERY            105
#define IDS_STARTUP_SESSION_MSG         106
#define IDS_STARTUP_SESSION             107
#define IDS_INVALID_NAME                108
#define IDS_LAST_SESSION                109
#define IDS_STRING110                   110
#define IDS_PREVIOUS_SESSION            110
#define IDC_ANSWER                      1001
#define IDC_CHECK_AUTOLOAD              1001
#define IDC_PROMPT                      1002
#define IDC_COMBO_SESSIONSLIST          1003
#define IDC_COMBO_SESSIONSLIST2         1004
#define IDC_BUTTON_DELETE               1005
#define IDC_EDIT_MAXUNDO                1006
#define IDC_CHECK_ASK                   1007

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
