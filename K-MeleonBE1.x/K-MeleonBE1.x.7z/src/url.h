class CUrlBar : public CComboBoxEx 
{
public:

    HWND m_hwndEdit;
   
   
    int Create(DWORD style, RECT &rect, CWnd *parentWnd, UINT id) {
        int ret = CComboBoxEx::Create(style | CBS_AUTOHSCROLL, rect, parentWnd, id);
        SetExtendedStyle(CBES_EX_CASESENSITIVE, CBES_EX_CASESENSITIVE);
      
        COMBOBOXEXITEM ci;
        ci.mask = CBEIF_IMAGE;
        ci.iItem = -1;
        ci.iImage = 15;
        SetItem(&ci);
      
        m_bFocusEnabled = theApp.preferences.bNewWindowHasUrlFocus;
        m_preserveUrlBarFocus = FALSE;
        m_changed = FALSE;
        m_bSelected = FALSE;
        m_iFocusCount = 0;

        CEdit *edit = GetEditCtrl();
        if (edit)
            m_hwndEdit = edit->m_hWnd;
      
        return ret;
    }
    inline void GetEnteredURL(CString& url) {
        GetEditCtrl()->GetWindowText(url);
    }
    inline void SetSelected(BOOL aSelected) {
        m_bSelected = aSelected;
    }
    inline BOOL GetSelectedURL(CString& url) {
        if (!m_bSelected) {
          int nIndex = GetCurSel();
          if (nIndex != LB_ERR) {
              GetLBText(nIndex, url);
              m_bSelected = TRUE;
              return TRUE;
          }
        }
        return FALSE;
    }   
    inline void SetCurrentURL(LPCTSTR pUrl) {
        if (!m_changed) {
            if (strnicmp(pUrl, "javascript:", 11))
                SetWindowText(pUrl);
            m_changed = FALSE;
        }
    }   
    inline void AddURLToList(CString& url, bool bAddToMRUList = true) {
        USES_CONVERSION;
        COMBOBOXEXITEM ci;
        ci.mask = CBEIF_TEXT | CBEIF_IMAGE | CBEIF_SELECTEDIMAGE;
        ci.iItem = 0;
        ci.iImage = 15;
        ci.iSelectedImage = 15;
        ci.pszText = const_cast<TCHAR *>((LPCTSTR)url);
        InsertItem(&ci);
      
        if(bAddToMRUList) {
            theApp.m_MRUList->AddURL((LPTSTR)(LPCTSTR)url);
            theApp.m_MRUList->SaveURLs();
            theApp.BroadcastMessage(UWM_REFRESHMRULIST, 0, 0);
        }
    }
    inline void RefreshMRUList() {
        ResetContent();
        LoadMRUList();
    }
    inline void LoadMRUList() {
        for (int i=theApp.m_MRUList->GetURLCount()-1;i>=0;i--) {
            USES_CONVERSION;
            CString urlStr(A2CT(theApp.m_MRUList->GetURL(i)));
            AddURLToList(urlStr, false);
        }
    }
    int SetSoftFocus() {
        if (IsIconic() || !IsWindowVisible())
	        return 0;
        HWND toplevelWnd = m_hWnd;
        while (::GetParent(toplevelWnd))
            toplevelWnd = ::GetParent(toplevelWnd);
        if (toplevelWnd != ::GetForegroundWindow() || 
            toplevelWnd != ::GetActiveWindow())
            return 0;
        SetFocus();
        return 1;
    }
    void MaintainFocus() {
       if (m_bFocusEnabled) {
          if (SetSoftFocus()) {
             m_preserveUrlBarFocus = TRUE;
             m_iFocusCount = 2;
          }
       }
    }
    BOOL CheckFocus() {
        return m_preserveUrlBarFocus;
    }
    void ReturnFocus(BOOL bDocumentLoading) {
        if (m_preserveUrlBarFocus && --m_iFocusCount >= 0) {
            if (!SetSoftFocus())
                EndFocus();
        }
        else {
            EndFocus();
        }
    }
    void EndFocus() {
        m_preserveUrlBarFocus = FALSE;
    }
    inline void EditChanged(BOOL state) {
        m_changed = state;
    }

protected:
    BOOL m_preserveUrlBarFocus;
    BOOL m_changed;
    BOOL m_bSelected;
    BOOL m_bFocusEnabled;
    int  m_iFocusCount;
};
