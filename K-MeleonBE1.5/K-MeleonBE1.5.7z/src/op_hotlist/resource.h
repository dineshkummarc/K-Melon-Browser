//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by op_hotlist.rc
//
#define IDD_CONFIG                      101
#define IDD_INSTALL                     102
#define IDD_EDIT_HOTLIST                103
#define IDD_SMARTBOOKMARK               104
#define IDR_CONTEXTMENU                 159
#define IDC_DRAG_CURSOR                 160
#define IDS_FILENOTFOUND                500
#define ID_CREATE                       501
#define IDS_FILECREATED                 501
#define ID_SEARCH                       502
#define IDS_CANTCREATEFILE              502
#define IDS_SAVE_FAILED                 503
#define IDS_ERROR                       504
#define IDS_FIND                        505
#define IDS_ALL_BOOKMARKS               506
#define IDS_NEVER                       507
#define IDS_WARN_CLOSE                  508
#define IDS_CLOSE_TITLE                 509
#define IDS_NEW_BOOKMARK                510
#define IDS_NEW_FOLDER                  511
#define IDS_MORE                        512
#define IDS_CONFIGURE                   513
#define IDS_ADD                         514
#define IDS_ADDLINK                     515
#define IDS_EDIT                        516
#define IDC_REBARENABLED                1000
#define IDC_HOTLIST_FILE                1001
#define IDC_BROWSE                      1002
#define IDC_MAX_MENU_LENGTH             1003
#define IDC_MIN_TB_SIZE                 1004
#define IDC_MAX_TB_SIZE                 1005
#define IDC_MENU_AUTODETECT             1006
#define IDC_TREE_HOTLIST                1007
#define IDC_STATIC_PROPERTIES           1008
#define IDC_STATIC_NAME                 1009
#define IDC_NAME                        1010
#define IDC_STATIC_URL                  1011
#define IDC_URL                         1012
#define IDC_STATIC_CREATED              1013
#define IDC_CREATED                     1014
#define IDC_STATIC_VISITED              1015
#define IDC_LAST_VISIT                  1016
#define IDC_STATIC_ORDER                1017
#define IDC_ORDER                       1018
#define IDC_STATIC_SHORT                1019
#define IDC_SHORT_NAME                  1020
#define IDC_STATIC_DESC                 1021
#define IDC_DESCRIPTION                 1022
#define IDC_SORTORDER_AZ                1023
#define IDC_SORTORDER_ZA                1024
#define IDC_FOLDERFIRST                 1025
#define IDC_USEORDER                    1026
#define IDC_INPUT                       1027
#define IDC_SEARCHTEXT                  1028
#define ID__BOOKMARK_DELETE             32791
#define ID__SET_TOOLBAR_FOLDER          32792
#define ID__NEW_FOLDER                  32795
#define ID__NEW_SEPARATOR               32796
#define ID__NEW_BOOKMARK                32797
#define ID__SETAS_TOOLBARFOLDER         32800
#define ID__SETAS_NEWBOOKMARKFOLDER     32802
#define ID__SETAS_BOOKMARKMENU          32803
#define ID__OPEN_BACKGROUND             32814
#define ID__OPEN                        32815
#define ID__BOOKMARK_CUT                32816
#define ID__BOOKMARK_COPY               32817
#define ID__BOOKMARK_PASTE              32818
#define ID__ZOOM                        32819

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        162
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1029
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
