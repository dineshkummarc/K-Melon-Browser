// THIS FILE WILL BE OVERWRITTEN BY DEV-C++!
// DO NOT EDIT!

#ifndef PRIVACY_PRIVATE_H
#define PRIVACY_PRIVATE_H

// VERSION DEFINITIONS
#define VER_STRING	"0.0.3.0"
#define VER_MAJOR	0
#define VER_MINOR	0
#define VER_RELEASE	3
#define VER_BUILD	0
#define COMPANY_NAME	""
#define FILE_VERSION	"0.0.3.0"
#define FILE_DESCRIPTION	"Privacy Plugin for K-Meleon"
#define INTERNAL_NAME	""
#define LEGAL_COPYRIGHT	"2004 - Romain Vallet"
#define LEGAL_TRADEMARKS	""
#define ORIGINAL_FILENAME	"privacy.dll"
#define PRODUCT_NAME	""
#define PRODUCT_VERSION	""

#endif //PRIVACY_PRIVATE_H
