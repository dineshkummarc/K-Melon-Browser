#ifdef _DEBUG
#define VERSION "0.4.5 Debug"
#else
#define VERSION "0.4.5"
#endif

#define BUILD_TIME __TIMESTAMP__
#define BUILD_NUMBER	462
