//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by history.rc
//
#define IDB_IMAGES                      159
#define IDB_ICON                        160
#define IDS_VIEW                        500
#define IDS_CONFIGURE                   501
#define IDS_FIND                        502
#define IDS_HISTORY                     503
#define IDS_ERROR                       504
#define IDS_LAST_HOUR                   505
#define IDS_TODAY                       506
#define IDS_THIS_WEEK                   507
#define IDS_LAST_WEEK                   508
#define IDS_2WEEKS_AGO                  509
#define IDS_3WEEKS_AGO                  510
#define IDS_NEVER                       511
#define IDS_Sunday                      512
#define IDS_Monday                      513
#define IDS_Tuesday                     514
#define IDS_Wednesday                   515
#define IDS_Thursday                    516
#define IDS_Friday                      517
#define IDS_Saturday                    518
#define IDS_January                     519
#define IDS_February                    520
#define IDS_March                       521
#define IDS_April                       522
#define IDS_May                         523
#define IDS_June                        524
#define IDS_July                        525
#define IDS_August                      526
#define IDS_September                   527
#define IDS_October                     528
#define IDS_November                    529
#define IDS_December                    530
#define IDS_LOAD_FAILED                 531
#define IDS_TITLE                       532
#define IDD_VIEW_HISTORY                700
#define IDD_CONFIG                      701
#define IDR_CONTEXTMENU                 759
#define IDC_REBARENABLED                1000
#define IDC_HISTORY_FILE                1001
#define IDC_BROWSE                      1002
#define IDC_MAX_MENU_LENGTH             1003
#define IDC_MIN_TB_SIZE                 1004
#define IDC_MAX_TB_SIZE                 1005
#define IDC_MENU_AUTODETECT             1006
#define IDC_TREE_HOTLIST                1007
#define IDC_STATIC_PROPERTIES           1008
#define IDC_STATIC_URL                  1011
#define IDC_URL                         1012
#define IDC_STATIC_VISITED              1015
#define IDC_LAST_VISIT                  1016
#define IDC_EXPIRE_DAYS                 1017
#define IDB_CLEAR                       1018
#define ID__BOOKMARK_DELETE             32791
#define ID__OPEN_BACKGROUND             32814
#define ID__OPEN                        32815
#define ID__ZOOM                        32819
#define ID__SORT_DATE                   32820
#define ID__SORT_URL                    32821

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
