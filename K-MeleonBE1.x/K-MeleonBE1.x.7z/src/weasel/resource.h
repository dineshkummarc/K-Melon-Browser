//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by weasel.rc
//
#define IDB_TOOLBAR_BUTTONS             101
#define IDD_DIALOG1                     102
#define IDC_EDIT_SERVER                 1000
#define IDC_EDIT_USERNAME               1001
#define IDC_EDIT_PASSWORD               1002
#define IDC_CHECK_ENABLED               1003
#define IDC_EDIT_SOUND                  1004
#define IDC_BUTTON_BROWSE               1005
#define IDC_BUTTON_TEST                 1006

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
