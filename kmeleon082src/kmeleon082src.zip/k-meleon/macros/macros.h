#define IDD_PROMPT		101
#define IDC_ANSWER		1001
#define IDC_PROMPT		1002

#define MSGEX_LENGTH		4096
