/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsIJSBridge.idl
 */

#ifndef __gen_nsIJSBridge_h__
#define __gen_nsIJSBridge_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

#ifndef __gen_nsIDOMWindow_h__
#include "nsIDOMWindow.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
class nsISimpleEnumerator; /* forward declaration */

class nsIArray; /* forward declaration */


/* starting interface:    kICmdList */
#define KICMDLIST_IID_STR "3d8ce8f0-5214-11db-b0de-0800200c9a66"

#define KICMDLIST_IID \
  {0x3d8ce8f0, 0x5214, 0x11db, \
    { 0xb0, 0xde, 0x08, 0x00, 0x20, 0x0c, 0x9a, 0x66 }}

class NS_NO_VTABLE kICmdList : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(KICMDLIST_IID)

  /* readonly attribute unsigned long id; */
  NS_IMETHOD GetId(PRUint32 *aId) = 0;

  /* readonly attribute string cmd; */
  NS_IMETHOD GetCmd(char * *aCmd) = 0;

  /* readonly attribute string desc; */
  NS_IMETHOD GetDesc(char * *aDesc) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_KICMDLIST \
  NS_IMETHOD GetId(PRUint32 *aId); \
  NS_IMETHOD GetCmd(char * *aCmd); \
  NS_IMETHOD GetDesc(char * *aDesc); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_KICMDLIST(_to) \
  NS_IMETHOD GetId(PRUint32 *aId) { return _to GetId(aId); } \
  NS_IMETHOD GetCmd(char * *aCmd) { return _to GetCmd(aCmd); } \
  NS_IMETHOD GetDesc(char * *aDesc) { return _to GetDesc(aDesc); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_KICMDLIST(_to) \
  NS_IMETHOD GetId(PRUint32 *aId) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetId(aId); } \
  NS_IMETHOD GetCmd(char * *aCmd) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetCmd(aCmd); } \
  NS_IMETHOD GetDesc(char * *aDesc) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetDesc(aDesc); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class _MYCLASS_ : public kICmdList
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_KICMDLIST

  _MYCLASS_();

private:
  ~_MYCLASS_();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(_MYCLASS_, kICmdList)

_MYCLASS_::_MYCLASS_()
{
  /* member initializers and constructor code */
}

_MYCLASS_::~_MYCLASS_()
{
  /* destructor code */
}

/* readonly attribute unsigned long id; */
NS_IMETHODIMP _MYCLASS_::GetId(PRUint32 *aId)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute string cmd; */
NS_IMETHODIMP _MYCLASS_::GetCmd(char * *aCmd)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute string desc; */
NS_IMETHODIMP _MYCLASS_::GetDesc(char * *aDesc)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


/* starting interface:    nsIJSBridge */
#define NS_IJSBRIDGE_IID_STR "83910267-7670-4493-99c1-dd540a036ef2"

#define NS_IJSBRIDGE_IID \
  {0x83910267, 0x7670, 0x4493, \
    { 0x99, 0xc1, 0xdd, 0x54, 0x0a, 0x03, 0x6e, 0xf2 }}

class NS_NO_VTABLE nsIJSBridge : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IJSBRIDGE_IID)

  enum { MENU_COMMAND = 1U };

  enum { MENU_POPUP = 2U };

  enum { MENU_INLINE = 3U };

  enum { MENU_PLUGIN = 4U };

  enum { MENU_SEPARATOR = 5U };

  /* void SetMenu (in string menu, in unsigned short type, in string label, in string command, in string before); */
  NS_IMETHOD SetMenu(const char *menu, PRUint16 type, const char *label, const char *command, const char *before) = 0;

  /* void RebuildMenu (in string menu); */
  NS_IMETHOD RebuildMenu(const char *menu) = 0;

  /* void id (in nsIDOMWindow window, in string id); */
  NS_IMETHOD Id(nsIDOMWindow *window, const char *id) = 0;

  /* void SendMessage (in string plugin, in string to, in string from, in long data1, inout long data2); */
  NS_IMETHOD SendMessage(const char *plugin, const char *to, const char *from, PRInt32 data1, PRInt32 *data2) = 0;

  /* void GetCmdList (out unsigned long length, [array, size_is (length), retval] out kICmdList list); */
  NS_IMETHOD GetCmdList(PRUint32 *length, kICmdList ***list) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIJSBRIDGE \
  NS_IMETHOD SetMenu(const char *menu, PRUint16 type, const char *label, const char *command, const char *before); \
  NS_IMETHOD RebuildMenu(const char *menu); \
  NS_IMETHOD Id(nsIDOMWindow *window, const char *id); \
  NS_IMETHOD SendMessage(const char *plugin, const char *to, const char *from, PRInt32 data1, PRInt32 *data2); \
  NS_IMETHOD GetCmdList(PRUint32 *length, kICmdList ***list); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIJSBRIDGE(_to) \
  NS_IMETHOD SetMenu(const char *menu, PRUint16 type, const char *label, const char *command, const char *before) { return _to SetMenu(menu, type, label, command, before); } \
  NS_IMETHOD RebuildMenu(const char *menu) { return _to RebuildMenu(menu); } \
  NS_IMETHOD Id(nsIDOMWindow *window, const char *id) { return _to Id(window, id); } \
  NS_IMETHOD SendMessage(const char *plugin, const char *to, const char *from, PRInt32 data1, PRInt32 *data2) { return _to SendMessage(plugin, to, from, data1, data2); } \
  NS_IMETHOD GetCmdList(PRUint32 *length, kICmdList ***list) { return _to GetCmdList(length, list); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIJSBRIDGE(_to) \
  NS_IMETHOD SetMenu(const char *menu, PRUint16 type, const char *label, const char *command, const char *before) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetMenu(menu, type, label, command, before); } \
  NS_IMETHOD RebuildMenu(const char *menu) { return !_to ? NS_ERROR_NULL_POINTER : _to->RebuildMenu(menu); } \
  NS_IMETHOD Id(nsIDOMWindow *window, const char *id) { return !_to ? NS_ERROR_NULL_POINTER : _to->Id(window, id); } \
  NS_IMETHOD SendMessage(const char *plugin, const char *to, const char *from, PRInt32 data1, PRInt32 *data2) { return !_to ? NS_ERROR_NULL_POINTER : _to->SendMessage(plugin, to, from, data1, data2); } \
  NS_IMETHOD GetCmdList(PRUint32 *length, kICmdList ***list) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetCmdList(length, list); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsJSBridge : public nsIJSBridge
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIJSBRIDGE

  nsJSBridge();

private:
  ~nsJSBridge();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsJSBridge, nsIJSBridge)

nsJSBridge::nsJSBridge()
{
  /* member initializers and constructor code */
}

nsJSBridge::~nsJSBridge()
{
  /* destructor code */
}

/* void SetMenu (in string menu, in unsigned short type, in string label, in string command, in string before); */
NS_IMETHODIMP nsJSBridge::SetMenu(const char *menu, PRUint16 type, const char *label, const char *command, const char *before)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void RebuildMenu (in string menu); */
NS_IMETHODIMP nsJSBridge::RebuildMenu(const char *menu)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void id (in nsIDOMWindow window, in string id); */
NS_IMETHODIMP nsJSBridge::Id(nsIDOMWindow *window, const char *id)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void SendMessage (in string plugin, in string to, in string from, in long data1, inout long data2); */
NS_IMETHODIMP nsJSBridge::SendMessage(const char *plugin, const char *to, const char *from, PRInt32 data1, PRInt32 *data2)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void GetCmdList (out unsigned long length, [array, size_is (length), retval] out kICmdList list); */
NS_IMETHODIMP nsJSBridge::GetCmdList(PRUint32 *length, kICmdList ***list)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIJSBridge_h__ */
