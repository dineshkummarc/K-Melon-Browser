#define IDD_CONFIG                      101
#define IDC_REBARENABLED                1000
