//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ie_favorites.rc
//
#define IDD_CONFIG                      101
#define IDD_INSTALL                     102
#define IDD_EDIT_FAVORITES              103
#define IDS_TOOLBAND_FAILED             500
#define ID_CREATE                       501
#define IDS_MORE                        501
#define ID_SEARCH                       502
#define IDS_CONFIGURE                   502
#define IDS_ADD                         503
#define IDS_ADDLINK                     504
#define IDS_EDIT                        505
#define IDC_REBARENABLED                1000
#define IDC_FAVORITES_PATH              1001
#define IDC_BROWSE                      1002
#define IDC_MAX_MENU_LENGTH             1003
#define IDC_MIN_TB_SIZE                 1004
#define IDC_MAX_TB_SIZE                 1005
#define IDC_MENU_AUTODETECT             1006
#define IDC_TREE_FAVORITES              1007
#define IDC_STATIC_PROPERTIES           1008
#define IDC_STATIC_NAME                 1009
#define IDC_NAME                        1010
#define IDC_STATIC_URL                  1011
#define IDC_URL                         1012
#define IDC_STATIC_CREATED              1013
#define IDC_CREATED                     1014
#define IDC_STATIC_VISITED              1015
#define IDC_LAST_VISIT                  1016
#define IDC_STATIC_ORDER                1017
#define IDC_ORDER                       1018
#define IDC_STATIC_SHORT                1019
#define IDC_SHORT_NAME                  1020
#define IDC_STATIC_DESC                 1021
#define IDC_DESCRIPTION                 1022
#define IDC_SORTORDER_AZ                1023
#define IDC_SORTORDER_ZA                1024
#define IDC_FOLDERFIRST                 1025

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
