//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by kmeleon_winamp.rc
//
#define IDS_PREV                        1
#define IDS_PLAY                        2
#define IDS_PAUSE                       3
#define IDS_STOP                        4
#define IDS_NEXT                        5
#define IDB_TOOLBAR_BUTTONS             162
#define ID_WINAMP_PREV                  2501
#define ID_WINAMP_NEXT                  2502

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        165
#define _APS_NEXT_COMMAND_VALUE         32839
#define _APS_NEXT_CONTROL_VALUE         1018
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
