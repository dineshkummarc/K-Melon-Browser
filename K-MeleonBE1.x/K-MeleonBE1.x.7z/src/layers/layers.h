#define IDD_CONFIG                      101
#define IDC_REBARENABLED                1000
#define IDC_REBARBOTTOM                 1001
