//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Dialogs.rc
//
#define IDD_PROMPT_DIALOG               128
#define IDD_PROMPT_PASSWORD_DIALOG      129
#define IDD_PROMPT_USERPASS_DIALOG      130
#define IDD_ALERT_CHECK_DIALOG          131
#define IDD_CONFIRM_CHECK_DIALOG        132
#define IDD_PROGRESS_DIALOG             133
#define IDD_CHOOSE_ACTION_DIALOG        134
#define IDC_PROMPT_ANSWER               1001
#define IDC_PROMPT_TEXT                 1002
#define IDC_USERNAME                    1003
#define IDC_PASSWORD                    1004
#define IDC_CHECK_SAVE_PASSWORD         1005
#define IDC_USERNAME_LABEL              1006
#define IDC_PASSWORD_LABEL              1007
#define IDC_CHECKBOX                    1008
#define IDC_MSG_TEXT                    1009
#define IDC_BTN1                        1010
#define IDC_BTN2                        1011
#define IDC_BTN3                        1012
#define IDC_ACTION                      1013
#define IDC_SAVING_FROM                 1014
#define IDC_PROGRESS                    1015
#define IDC_CONTENT_TYPE                1016
#define IDC_SAVE_TO_DISK                1017
#define IDC_OPEN_USING                  1018
#define IDC_CHOOSE_APP                  1019
#define IDC_APP_NAME                    1020

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        143
#define _APS_NEXT_COMMAND_VALUE         32789
#define _APS_NEXT_CONTROL_VALUE         1022
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
